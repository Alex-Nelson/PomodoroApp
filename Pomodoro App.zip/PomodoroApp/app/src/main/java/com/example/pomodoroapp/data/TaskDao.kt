package com.example.pomodoroapp.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

/**
 * The DAO (Data Access Object) for the Task entity.
 * */
@Dao
interface TaskDao {

    /** Insert a task into the table */
    @Insert
    suspend fun insert(task: Task)

    /** Update the task */
    @Update
    suspend fun update(task: Task)

    /** Select a task from the table with the corresponding id */
    @Query("SELECT * FROM task_table WHERE taskId = :key")
    suspend fun getTask(key: Long): Task

    /** Select the most recently added task */
    @Query("SELECT * FROM task_table ORDER BY taskId DESC LIMIT 1")
    suspend fun getNewTask(): Task

    /** Delete a task from the table */
    @Query("DELETE FROM task_table WHERE taskId = :key")
    suspend fun deleteTask(key: Long)

    /** Delete all tasks from the table */
    @Query("DELETE FROM task_table")
    suspend fun clear()

    /** Select all tasks from the table */
    @Query("SELECT * FROM task_table")
    fun getAllTasks(): LiveData<List<Task>>
}